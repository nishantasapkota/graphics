#include<stdio.h>
#include<conio.h>
#include<graphics.h>
#include<math.h>
#include<alloc.h>
#include<stdlib.h>
int n,i,p[20],q[20];
int convertx(int x);
int converty(int y);
void axis(void);
void init(void);
void shear(void);
void reflect(void);
int main()
{
 int ch,gd=DETECT,gm;
 initgraph(&gd,&gm,(char*)"");
 axis();
 printf("\b");
 cleardevice();
 printf("Enter the number of vertices:");
 scanf("%d",&n);
 printf("Enter the co-ordinate center the first vertex at the end");
 for(i=0;i<2*n+2;i++)
 scanf("%d",&p[i]);
 clrscr();
 init();
 getch();
 do
 {
  clrscr();
  cleardevice();
  printf("\n \t\t2D-Transformation \n1.reflection\n2.shearing\n");
  printf("\n\nEnter yuor choice:\n");
  scanf("%d",&ch);
  clrscr();
  cleardevice();
  switch(ch)
  {
   case 1:
   reflect();
   break;
   case 2:
   shear();
   break;
  }
 }
while(ch!=3);
 closegraph();
}
void axis(void)
{
 cleardevice();
 setlinestyle(SOLID_LINE,1,1);
 line(320,0,320,getmaxy());
 line(0,240,getmaxx(),240);
 outtextxy(325,245,"0");
 line(316,40,324,40);
 outtextxy(325,41,"400");
 line(316,440,324,440);
 outtextxy(325,441,"-400");
 line(20,236,20,244);
 outtextxy(19,250,"-600");
 line(620,236,620,244);
 outtextxy(608,250,"600");
}
void init()
{
 cleardevice();
 axis();
 setcolor(YELLOW);
 setlinestyle(SOLID_LINE,1,1);
 for(i=0;i<2*n+2;i+=2)
 q[i]=convertx(p[i]);
 for(i=1;i<2*n+2;i+=2)
 q[i]=converty(p[i]);
 drawpoly(n+1,q);
 setcolor(WHITE);
}
int convertx(int x)
{
 x=x/2;
 return(x+=320);
}
int converty(int y)
{
 y=y/2;
 return(y+=240-y);
}
 void shear()
{
 int sh[20],sho[20];
 float shx,shy,c;
 printf("(1)share relate to x-axis\n");
 printf("(2)share relate to y-axis\n");
 printf("\n Enter your choice:");
 scanf("%f",&c);
 if(c==1)
 {
  init();
  printf(" Enter the shear factor(shx):");
  scanf("%f",&shx);
  for(i=1;i<2*n+2;i+=2)
  sh[i]=p[i]+(shx*(p[i+1]));
  for(i=0;i<2*n+2;i+=2)
  sh[i]=p[i];
 }
 else
 {
  init();
  printf("\enter the shear factor(shy):");
  scanf("%f",&shy);
  for(i=1;i<2*n+2;i+=2)
  sh[i]=(shy*p[i-1])+p[i];
  for(i=0;i<2*n+2;i+=2)
  sh[i]=p[i];
 }
 setlinestyle(DOTTED_LINE,1,1);
 for(i=0;i<2*n+2;i+=2)
 sho[i]=convertx(sh[i]);
 for(i=1;i<2*n+2;i+=2)
 sho[i]=converty(sh[i]);
 drawpoly(n+1,sho);
 getch();
}
void reflect()
{
 int i,c,rf[20],rft[20];
 printf("\n 1.x-axis reflection\n 2.y-axis reflection");
 printf("\n Enter the choice:");
 scanf("%d",&c);
 clrscr();
 cleardevice();
 if(c==1)
 {
  for(i=1;i<2*n+2;i+=2)
  rf[i]=p[i]*(-1);
  for(i=0;i<2*n+2;i+=2)
  rf[i]=p[i];
 }
 else
 {
  for(i=0;i<2*n+2;i+=2)
  rf[i]=p[i]*(-1);
  for(i=1;i<2*n+2;i+=2)
  rf[i]=p[i];
 }
 init();
 setlinestyle(DOTTED_LINE,1,1);
 for(i=0;i<2*n+2;i+=2)
 rft[i]=convertx(rf[i]);
 for(i=1;i<2*n+2;i+=2)
 rft[i]=converty(rf[i]);
 drawpoly(n+1,rft);
 getch();
}