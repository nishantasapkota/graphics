#include<graphics.h>
#include<stdio.h>
#include<conio.h>

 ellipse(int h, int k, int a, int b) {
    int x, y, p;
    x = 0;
    y = b;
    p = (b*b) - (a*a*b) + ((a*a) / 4);

    while((2*x*b*b) < (2*y*a*a)) {
        putpixel(h+x, k-y,15);
        putpixel(h-x, k+y,15);
        putpixel(h+x, k+y,15);
        putpixel(h-x, k-y,15);

        x = x+1;
        if(p < 0) {
p = p + b*b*(2*x + 1);
        } else {
y = y - 1;
p = p + b*b*(2*x + 1) - (a*a*2*y);
        }
   }

    p = ((float) x+0.5) * ((float) x + 0.5) *b*b + (y-1) *(y-1) *a*a - a*a*b*b;
    
    while(y >= 0) {
        putpixel(h+x, k-y, 15);
        putpixel(h-x, k+y, 15);
        putpixel(h+x, k+y, 15);
        putpixel(h-x, k-y, 15);

        y = y - 1;
        if(p > 0) {
p = p - a*a*(2*y - 1);
        } else {
x = x+1;
    	p=p - a*a*(2*y - 1) + b*b*2*x;
        }
   }

int main() {
    int gd = DETECT, gm;
    int xc, yc, a, b;
    
    printf("----Midpoint Ellipse Drawing Algorithm----\n\n");
    printf("Enter values for center of ellipse (xc, yc):\n");
    scanf("%d%d", &xc, &yc);
    
    printf("Enter values for a and b:\n");
    scanf("%d%d", &a, &b);

    initgraph(&gd, &gm,(char*) "");

    ellipse(xc, yc, a, b);
    getch();
    closegraph();
}
