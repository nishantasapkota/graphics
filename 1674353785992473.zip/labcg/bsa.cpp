
#include<stdio.h>
#include<math.h>
#include<graphics.h>
void bsaLine(int x0, int y0, int xn, int yn) {
    int dx, dy, p, x, y, steps;

    dx=xn-x0;
    dy=yn-y0;
    p = 2*dy-dx;

    if(abs(dx)>abs(dy))
        steps = dx;
    else
        steps = dy;

    x=x0;
    y=y0;
    p=2*dy-dx;
    putpixel(x, y, 15);

    for(int i=0; i<steps; i++) {
        x=x+1;
        if(p>=0) {
            y=y+1;
            p=p+2*(dy-dx);
        } else {
            p=p+2*dy;
        }
        putpixel(x, y, 15);
    }
}

int main() {
    int gd=DETECT, gm, error, x0, y0, xn, yn;

    printf("----BSA Line Drawing Algorithm----\n\n");
    printf("Enter values for (x0, y0):\n");
    scanf("%d%d", &x0, &y0);

    printf("Enter values for (xn, yn):\n");
    scanf("%d%d", &xn, &yn);

    initgraph(&gd, &gm, (char*)"");
    bsaLine(x0, y0, xn, yn);

    getch();
    closegraph();
    return 0;
}

