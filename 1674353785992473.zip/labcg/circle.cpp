#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>

void midpointCircle(int xc, int yc, int r){
    int pk, xk, yk;
    xk = 0;
    yk = r;

    putpixel(xc+xk, yc+yk, 15);
    putpixel(xc-xk, yc+yk, 15);
    putpixel(xc+xk, yc-yk, 15);
    putpixel(xc-xk, yc-yk, 15);
    putpixel(xc+yk, yc+xk, 15);
    putpixel(xc-yk, yc+xk, 15);
    putpixel(xc+yk, yc-xk, 15);
    putpixel(xc-yk, yc-xk, 15);
    
    pk = 1-r; 

    while(xk < yk){
        xk = xk + 1;

        if(pk < 0){
            pk = pk + 2*xk + 1;
        } else {
            yk = yk - 1;
            pk = pk + 2*xk + 1 - 2*yk;
        }

        putpixel(xc+xk, yc+yk, 15);
        putpixel(xc-xk, yc+yk, 15);
        putpixel(xc+xk, yc-yk, 15);
        putpixel(xc-xk, yc-yk, 15);
        putpixel(xc+yk, yc+xk, 15);
        putpixel(xc-yk, yc+xk, 15);
        putpixel(xc+yk, yc-xk, 15);
        putpixel(xc-yk, yc-xk, 15);
    }
} 
int main(){
    int gd = DETECT, gm;
    int xc, yc, r;

    printf("----BSA Circle Drawing Algorithm----\n\n");
    printf("Enter coordinates for center of circle (xc, yc):\n");
    scanf("%d%d", &xc, &yc);

    printf("Enter the radius:\n");
    scanf("%d", &r);

    initgraph(&gd, &gm, (char*)"");
    midpointCircle(xc, yc, r);

    getch();
    closegraph();
    return 0;
}
