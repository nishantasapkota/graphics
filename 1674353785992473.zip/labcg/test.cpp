#include<graphics.h>

int main(int argc,char const *argv[])
{
   
int gd=DETECT ,gm;
   initgraph(&gd, &gm,  (char*)"");

 
   circle(32, 240, 20);
  
 getch();
   closegraph();
   return 0;
}